Deflemask instruments are provided with permission from the Deflemask
development team.

https://www.deflemask.com/

Consider purchasing Deflemask if you would like to use the tool to create
your own instruments and/or YM2151 tracks for use on the Commander X16
(or even if you just like making Chiptunes - it's a great program)

-- ZeroByte
